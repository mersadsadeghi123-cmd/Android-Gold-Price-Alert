رصد طلای ۱۸ عیار - پروژه Android
API: https://api.digikala.com/wealth/v1/prices/
در Android Studio باز کنید و Build > Build APK(s) را بزنید.
