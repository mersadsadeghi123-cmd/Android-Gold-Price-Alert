package com.mersad.gold18

import android.app.*
import android.os.*
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var price: TextView
    private lateinit var status: TextView
    private lateinit var target: EditText
    private val exec = Executors.newSingleThreadExecutor()
    private val api = "https://api.digikala.com/wealth/v1/prices/"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(32,50,32,32) }
        val title=TextView(this).apply { text="رصد طلای ۱۸ عیار"; textSize=28f; gravity=Gravity.CENTER; setTextColor(Color.BLACK); setPadding(0,0,0,28) }
        price=TextView(this).apply { text="در حال دریافت قیمت..."; textSize=25f; gravity=Gravity.CENTER; setTextColor(Color.rgb(20,110,20)); setPadding(0,20,0,20) }
        target=EditText(this).apply { hint="قیمت هدف"; inputType=2; textSize=18f }
        val save=Button(this).apply { text="ذخیره قیمت هدف" }
        val refresh=Button(this).apply { text="بروزرسانی قیمت" }
        status=TextView(this).apply { textSize=15f; gravity=Gravity.CENTER; setPadding(0,16,0,0) }
        box.addView(title); box.addView(price); box.addView(target); box.addView(save); box.addView(refresh); box.addView(status); setContentView(box)
        val sp=getSharedPreferences("settings",0); sp.getLong("target",0).takeIf{it>0}?.let{target.setText(it.toString())}
        save.setOnClickListener { val t=target.text.toString().toLongOrNull()?:0; sp.edit().putLong("target",t).apply(); status.text="قیمت هدف ذخیره شد" }
        refresh.setOnClickListener { fetch() }; fetch()
    }
    private fun fetch(){
        status.text="در حال دریافت..."
        exec.execute { try {
            val c=URL(api).openConnection() as HttpURLConnection; c.connectTimeout=10000; c.readTimeout=10000
            val body=c.inputStream.bufferedReader().use{it.readText()}; c.disconnect()
            val p=JSONObject(body).getJSONObject("gold18").getLong("price")
            runOnUiThread { price.text=String.format(Locale.US,"%,d تومان",p); status.text="آخرین بروزرسانی: "+SimpleDateFormat("HH:mm:ss",Locale.US).format(Date()); val t=target.text.toString().toLongOrNull()?:0; if(t>0&&p<=t) AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت طلای ۱۸ عیار به قیمت هدف رسیده است.").setPositiveButton("باشه",null).show() }
        } catch(e:Exception){ runOnUiThread{status.text="خطا در دریافت قیمت"} } }
    }
}
